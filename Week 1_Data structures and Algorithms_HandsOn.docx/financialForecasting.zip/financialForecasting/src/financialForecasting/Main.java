package financialForecasting;

public class Main {

	public static void main(String[] args) {
		 double currentValue = 1000; // Starting amount
	        double rate = 0.05; // 5% growth
	        int years = 5;

	        System.out.println("=== Financial Forecasting ===");
	        double future = Forecast.futureValue(currentValue, rate, years);
	        System.out.printf("Future Value (Recursive): %.2f%n", future);

	        double[] memo = new double[years + 1];
	        double futureMemo = Forecast.futureValueMemo(currentValue, rate, years, memo);
	        System.out.printf("Future Value (Memoized): %.2f%n", futureMemo);

	        double futureIter = Forecast.futureValueIterative(currentValue, rate, years);
	        System.out.printf("Future Value (Iterative): %.2f%n", futureIter);
	    }

}


