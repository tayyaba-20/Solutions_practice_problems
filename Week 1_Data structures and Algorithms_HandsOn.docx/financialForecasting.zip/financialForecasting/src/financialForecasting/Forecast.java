package financialForecasting;

public class Forecast {
	 // Recursive method to compute future value
    public static double futureValue(double currentValue, double rate, int years) {
        if (years == 0) {
            return currentValue;
        } else {
            return futureValue(currentValue, rate, years - 1) * (1 + rate);
        }
    }

    // Optimized version using memoization (optional)
    public static double futureValueMemo(double currentValue, double rate, int years, double[] memo) {
        if (years == 0) return currentValue;
        if (memo[years] != 0) return memo[years];

        memo[years] = futureValueMemo(currentValue, rate, years - 1, memo) * (1 + rate);
        return memo[years];
    }

    // Iterative version (optional)
    public static double futureValueIterative(double currentValue, double rate, int years) {
        for (int i = 0; i < years; i++) {
            currentValue *= (1 + rate);
        }
        return currentValue;
    }

}
