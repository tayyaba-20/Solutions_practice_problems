package com.search;

public class Main {

	public static void main(String[] args) {
		  Product[] products = {
		            new Product(101, "Laptop", "Electronics"),
		            new Product(102, "Shoes", "Fashion"),
		            new Product(103, "Watch", "Accessories"),
		            new Product(104, "Mobile", "Electronics"),
		            new Product(105, "Book", "Stationery")
		        };

		        String target = "Mobile";
		        System.out.println("To Find out target Mobile");
		        System.out.println("\n=== Linear Search ===");
		        long start1 = System.nanoTime();
		        Product result1 = ProductSearch.linearSearch(products, target);
		        long end1 = System.nanoTime();
		        System.out.println(result1 != null ? result1 : "Product not found");
		        System.out.println("Time: " + (end1 - start1) + " ns\n");

		        System.out.println("=== Binary Search ===");
		        long start2 = System.nanoTime();
		        Product result2 = ProductSearch.binarySearch(products, target);
		        long end2 = System.nanoTime();
		        System.out.println(result2 != null ? result2 : "Product not found");
		        System.out.println("Time: " + (end2 - start2) + " ns");
		    }

	}


