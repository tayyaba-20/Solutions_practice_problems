SELECT c.name, l.due_date
FROM customers c
JOIN loans l ON c.customer_id = l.customer_id
WHERE l.due_date <= CURDATE() + INTERVAL 30 DAY;
