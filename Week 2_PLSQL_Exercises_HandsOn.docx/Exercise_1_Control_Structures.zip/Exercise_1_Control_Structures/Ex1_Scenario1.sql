DELIMITER //

CREATE PROCEDURE apply_discount_to_senior_customers()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE cust_id INT;
    DECLARE cur CURSOR FOR SELECT customer_id FROM customers WHERE age > 60;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO cust_id;
        IF done THEN
            LEAVE read_loop;
        END IF;

        UPDATE loans
        SET interest_rate = interest_rate - 1.00
        WHERE customer_id = cust_id;
    END LOOP;

    CLOSE cur;
END //

DELIMITER ;

CALL apply_discount_to_senior_customers();
