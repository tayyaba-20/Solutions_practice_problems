UPDATE customers
SET is_vip = TRUE
WHERE balance > 10000 AND customer_id IS NOT NULL;
