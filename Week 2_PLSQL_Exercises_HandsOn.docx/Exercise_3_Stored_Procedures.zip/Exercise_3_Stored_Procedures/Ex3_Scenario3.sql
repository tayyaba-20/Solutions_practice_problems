DELIMITER $$

CREATE PROCEDURE TransferFunds(
    IN from_acc INT,
    IN to_acc INT,
    IN amount DECIMAL(10,2)
)
BEGIN
    DECLARE current_balance DECIMAL(10,2);

    -- Get current balance of source account
    SELECT balance INTO current_balance
    FROM accounts
    WHERE account_id = from_acc;

    -- Check if sufficient funds
    IF current_balance >= amount THEN
        -- Deduct from source
        UPDATE accounts
        SET balance = balance - amount
        WHERE account_id = from_acc;

        -- Add to destination
        UPDATE accounts
        SET balance = balance + amount
        WHERE account_id = to_acc;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Insufficient Balance!';
    END IF;
END $$

DELIMITER ;
SET SQL_SAFE_UPDATES = 0;
CALL TransferFunds(101, 102, 500.00);
