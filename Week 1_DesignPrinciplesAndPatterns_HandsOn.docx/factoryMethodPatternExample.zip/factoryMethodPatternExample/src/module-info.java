module factoryMethodPatternExample {
}