package com.factory;

interface Document {
	void open();
}
