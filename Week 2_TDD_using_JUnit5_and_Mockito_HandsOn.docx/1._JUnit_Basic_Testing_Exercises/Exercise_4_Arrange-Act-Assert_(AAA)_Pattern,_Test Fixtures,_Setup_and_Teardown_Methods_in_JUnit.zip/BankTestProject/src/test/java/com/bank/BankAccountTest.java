package com.bank;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;

public class BankAccountTest {

    private BankAccount account;

    @Before
    public void setUp() {
        account = new BankAccount(1000.0);
        System.out.println("Account setup complete");
    }

    @After
    public void tearDown() {
        account = null;
        System.out.println("Teardown complete");
    }

    @Test
    public void testDeposit() {
        // Arrange handled in @Before

        // Act
        account.deposit(500);

        // Assert
        assertEquals(1500.0, account.getBalance(), 0.01);
    }

    @Test
    public void testWithdraw() {
        account.withdraw(200);
        assertEquals(800.0, account.getBalance(), 0.01);
    }
}
