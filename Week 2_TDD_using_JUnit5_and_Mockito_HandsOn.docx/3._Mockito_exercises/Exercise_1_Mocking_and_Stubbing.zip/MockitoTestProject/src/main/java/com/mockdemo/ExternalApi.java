
package com.mockdemo;

public interface ExternalApi {
    String getData();
}
